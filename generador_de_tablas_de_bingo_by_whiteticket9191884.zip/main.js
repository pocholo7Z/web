import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

const form = document.getElementById('bingo-form');
const cantidadInput = document.getElementById('cantidad');
const tablesDiv = document.getElementById('bingo-tables');
const descargaBtn = document.getElementById('descargar-btn');
const descargaWrapper = document.getElementById('descarga-wrapper');

form.addEventListener('submit', function (e) {
    e.preventDefault();
    const cant = parseInt(cantidadInput.value, 10);
    if (isNaN(cant) || cant < 1 || cant > 4000) {
        alert("Por favor ingrese una cantidad entre 1 y 4000.");
        return;
    }
    generarTablas(cant);
});

descargaBtn.addEventListener('click', async function () {
    await descargarPDF();
});

function generarTablas(cantidad) {
    tablesDiv.innerHTML = "";
    descargaWrapper.style.display = cantidad > 0 ? 'block' : 'none';

    // Para renderizar solo las primeras 12 tablas en pantalla por performance.
    const showLimit = 12;
    for (let i = 1; i <= Math.min(cantidad, showLimit); i++) {
        tablesDiv.appendChild(crearContenedorTablaBingo(i, generarTablaBingo()));
    }
    if (cantidad > showLimit) {
      let extra = document.createElement('p');
      extra.style.fontSize = "15px";
      extra.innerHTML = `...Mostrando solo las primeras <b>${showLimit}</b> tablas de <b>${cantidad}</b> generadas (todas se descargan en PDF).`;
      tablesDiv.appendChild(extra);
    }
    window.bingoTablasGeneradas = Array.from({length: cantidad}, () => generarTablaBingo());
}

function crearContenedorTablaBingo(indice, tabla) {
    let div = document.createElement('div');
    div.className = 'bingo-table-container';

    let titulo = document.createElement('div');
    titulo.className = 'bingo-title';
    titulo.textContent = `Tabla #${indice}`;
    div.appendChild(titulo);

    let tablaElem = document.createElement('table');
    tablaElem.className = "bingo-table";
    let header = tablaElem.insertRow();
    ['B', 'I', 'N', 'G', 'O'].forEach(letra => {
        let th = document.createElement('th');
        th.textContent = letra;
        header.appendChild(th);
    });

    for (let fila = 0; fila < 5; fila++) {
        let row = tablaElem.insertRow();
        for (let col = 0; col < 5; col++) {
            let cell = row.insertCell();
            if (fila === 2 && col === 2) {
                cell.textContent = "★";
                cell.className = "free";
            } else {
                cell.textContent = tabla[col][fila];
            }
        }
    }
    div.appendChild(tablaElem);
    return div;
}

function generarTablaBingo() {
    // Rango de cada columna:
    // B: 1-15,  I: 16-30, N: 31-45, G: 46-60, O: 61-75
    let tabla = [];
    const ranges = [
        [1, 15],
        [16, 30],
        [31, 45],
        [46, 60],
        [61, 75]
    ];
    for (let [min, max] of ranges) {
        let numeros = [];
        for (let i = min; i <= max; i++) numeros.push(i);
        // Shuffle y tome 5
        for (let i = numeros.length - 1; i > 0; i--) {
            let j = Math.floor(Math.random() * (i + 1));
            [numeros[i], numeros[j]] = [numeros[j], numeros[i]];
        }
        tabla.push(numeros.slice(0,5));
    }
    // Cell central es FREE, pero solo visual: dejar el slot para saber que es la FREE
    tabla[2][2] = "★"; // Just placeholder, renderizado especial
    return tabla;
}

// Función para descargar todas las tablas generadas en un PDF (se ajusta al formato)
async function descargarPDF() {
    const tablas = window.bingoTablasGeneradas;
    if (!tablas || !tablas.length) return;

    const doc = new jsPDF({unit:'pt',format:'a4'});
    const anchoPagina = 595.28, altoPagina = 841.89; // puntos (A4)

    const tablasPorPagina = 4;
    let xOffsets = [40, anchoPagina/2 + 10];
    let yOffsets = [50, altoPagina/2 - 40];
    let posTablas = [
      [0,0],[1,0],[0,1],[1,1]
    ];
    let tablaW = 220, tablaH = 180;

    for (let i = 0; i < tablas.length; i++) {
        const pagIndex = i % tablasPorPagina;
        if (i>0 && pagIndex === 0) doc.addPage();

        let [xIdx, yIdx] = posTablas[pagIndex];
        let x = xOffsets[xIdx], y = yOffsets[yIdx];
        await drawTablaEnPDF(doc, tablas[i], `Tabla #${i+1}`, x, y, tablaW, tablaH);
    }

    doc.save(`bingos_${tablas.length}.pdf`);
}

async function drawTablaEnPDF(doc, tabla, titulo, x, y, tablaW, tablaH) {
    const cellW = tablaW/5, cellH = tablaH/6;
    doc.setFontSize(15);
    doc.setFont("helvetica", "bold");
    doc.text(titulo, x + tablaW/2, y - 6, {align:'center'});

    // Header:
    const letras = ['B','I','N','G','O'];
    doc.setFillColor(107,123,189);
    doc.setTextColor(255);
    for(let i=0;i<5;i++) {
        doc.rect(x + i*cellW, y, cellW, cellH, 'F');
        doc.text(letras[i], x + i*cellW + cellW/2, y+cellH/2 + 4, {align:'center', baseline:'middle'});
    }
    // celdas:
    doc.setFont("helvetica", "normal");
    doc.setTextColor(44);
    for(let fila=0;fila<5;fila++) {
        for(let col=0;col<5;col++) {
            let cellX = x + col*cellW, cellY = y + (fila+1)*cellH;
            // FREE
            if(fila ===2 && col===2) {
                doc.setFillColor(217,230,252);
                doc.rect(cellX, cellY, cellW, cellH, 'F');
                doc.setFont("helvetica","bold");
                doc.setTextColor(69,86,132);
                doc.text("★", cellX + cellW/2, cellY + cellH/2 + 4, {align:'center',baseline:'middle'});
                doc.setFont("helvetica","normal");
                doc.setTextColor(44);
            } else {
                doc.setFillColor(255,255,255);
                doc.rect(cellX, cellY, cellW, cellH, 'F');
                doc.text(String(tabla[col][fila]), cellX + cellW/2, cellY + cellH/2 + 4, {align:'center',baseline:'middle'});
            }
            doc.setDrawColor(162,178,221);
            doc.rect(cellX, cellY, cellW, cellH, 'S');
        }
    }
}

